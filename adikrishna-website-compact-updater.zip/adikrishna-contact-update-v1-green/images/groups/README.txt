Group banner photos go here, named as the group (e.g. grains-and-cereal.jpg). Wide JPG, about 1600x500 px.
Easiest way: open update-images.html, switch to "Banner photos", choose photos, download the ZIP and unzip it into the site folder.
