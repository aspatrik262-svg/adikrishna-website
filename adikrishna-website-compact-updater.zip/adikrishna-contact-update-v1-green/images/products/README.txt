Product photos go here, named exactly as the product (e.g. rice.jpg). JPG, about 800x640 px (5:4).
Easiest way to fill this folder: open update-images.html in a browser, choose photos, download the ZIP and unzip it into the site folder.
